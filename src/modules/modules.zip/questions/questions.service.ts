import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { QuizQuestion } from '../quizzes/database/quiz-question.entity';
import { CreateBankQuestionDto, UpdateBankQuestionDto } from './dtos/questions.dto';
import * as XLSX from 'xlsx';
import type { Express } from 'express';
import { QuestionType } from 'src/constant/enum';

@Injectable()
export class QuestionsService {
  constructor(
    @InjectRepository(QuizQuestion)
    private questionsRepository: Repository<QuizQuestion>,
  ) {}

  create(dto: CreateBankQuestionDto) {
    // Dữ liệu 'answers' đã là JSON object từ DTO, TypeORM sẽ tự xử lý khi lưu vào cột json
    const newQuestion = this.questionsRepository.create(dto);
    return this.questionsRepository.save(newQuestion);
  }

  findAll() {
    return this.questionsRepository.find();
  }

  async findOne(id: string) {
    const q = await this.questionsRepository.findOneBy({ question_id: id });
    if (!q) throw new NotFoundException('Question not found');
    return q;
  }

  async update(id: string, dto: UpdateBankQuestionDto) {
    // Khi update JSON, cần cẩn thận vì nó sẽ ghi đè toàn bộ cột answers
    const question = await this.questionsRepository.preload({ question_id: id, ...dto });
    if (!question) throw new NotFoundException('Question not found');
    return this.questionsRepository.save(question);
  }

  async remove(id: string) {
    const q = await this.findOne(id);
    await this.questionsRepository.remove(q);
    return { message: 'Question removed from bank' };
  }

  async importFromExcel(file?: Express.Multer.File) {
    if (!file) throw new BadRequestException('File is required');

    const workbook = XLSX.read(file.buffer, { type: 'buffer' });
    const sheetName = workbook.SheetNames?.[0];
    if (!sheetName) throw new BadRequestException('Excel file is empty');

    const worksheet = workbook.Sheets[sheetName];
    const rows = XLSX.utils.sheet_to_json<Record<string, any>>(worksheet, {
      defval: null,
      raw: false,
      blankrows: false,
    });

    if (!rows.length) throw new BadRequestException('No data found in Excel file');

    const validKeys = ['a', 'b', 'c', 'd'];
    const entities: QuizQuestion[] = [];
    const errors: string[] = [];

    rows.forEach((row, index) => {
      const rowNumber = index + 2;
      const questionText = row['question_text']?.toString().trim();
      const optionA = row['option_a']?.toString().trim();
      const optionB = row['option_b']?.toString().trim();
      const optionC = row['option_c']?.toString().trim();
      const optionD = row['option_d']?.toString().trim();
      const correctAnswer = row['correct_answer']?.toString().trim().toLowerCase();
      const category = row['category']?.toString().trim() ?? null;

      // Validation cơ bản
      if (!questionText || !optionA || !optionB || !correctAnswer) {
        errors.push(`Row ${rowNumber}: missing required data`);
        return;
      }

      if (!validKeys.includes(correctAnswer)) {
        errors.push(`Row ${rowNumber}: correct_answer must be 'a','b','c','d'`);
        return;
      }

     
      const answers = [
        { answer: optionA, isCorrect: correctAnswer === 'a' },
        { answer: optionB, isCorrect: correctAnswer === 'b' },
      ];
      
      if (optionC) answers.push({ answer: optionC, isCorrect: correctAnswer === 'c' });
      if (optionD) answers.push({ answer: optionD, isCorrect: correctAnswer === 'd' });

      const entity = this.questionsRepository.create({
        question_text: questionText,
        category: category,
        type: QuestionType.MULTIPLE_CHOICE, // Mặc định cho Excel cũ
        answers: answers, // Lưu mảng này vào cột json
      });

      entities.push(entity);
    });

    if (!entities.length) {
      throw new BadRequestException(errors.length ? `Errors: ${errors.join('; ')}` : 'No valid rows');
    }

    await this.questionsRepository.save(entities);
    return { imported: entities.length, errors };
  }
}